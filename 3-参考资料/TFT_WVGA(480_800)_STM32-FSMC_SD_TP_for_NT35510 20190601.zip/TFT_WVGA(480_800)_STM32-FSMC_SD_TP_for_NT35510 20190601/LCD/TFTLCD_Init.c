/*********************************  *************************************
* Copyright (c) 2017 ����Һ����ʾ��
* All rights reserved.
*
* �ļ���   ��TFTLCD_Init.c    
* ����     ������������
*
* ��ǰ�汾 ��V1.0
* ��    �� ��CGY
* ������� ��2017-12-01
* �޸����� ����һ�汾
*	΢�źţ�wxjcgy20120815
*	E-mail : 68771083@qq.com
*	�Ա���ʾ���������� https://shop150276963.taobao.com/?spm=a313o.7775905.1998679131.d0011.pdIFpT           						                          	
*******************************************************************************/
#include "TFTLCD_Init.h"
///////////////////////////
u8 lcd_id[12]; //���LCD ID�ַ���
#define	dir1 0  //���÷���˳ʱ��rotate��0�������ã�1��FPC����ߣ�2��FPC���ϱߣ�3��FPC���ұ�
/*************���³�ʼ����������ô���*******************/
/*************************************/

void LCD_Init(void)
{
/*************�ԣ̣ãĳ�ʼ��ǰ���и�λ*******************/
	LCD_RESET(); //����ʾ������ϵ縴λ	
/*************�ԣ̣ãĸ�λ*****************************/

/*************���¿�ʼ��ʼ��*******************/
/*************���¿�ʼ��ʼ��*******************/
		
	NT35510_HSD43_Initial();
 
	LCD_Set();  //������ʾ������	 ��Ҫ���ã���ʾ���ܶ��õ����õģ�
///////////////////
															
/*************�ԣ̣ã�����������********************/	
/*************END******************/
/*************END******************/

}


/*************���¿�ʼ��ʼ��*******************/	
/*************���¿�ʼ��ʼ��*******************/	

void NT35510_HSD43_Initial(void)
{

///NT35510-HSD43
//PAGE1
LCD_WR_REG(0xF000);    LCD_WR_DATA(0x0055);
LCD_WR_REG(0xF001);    LCD_WR_DATA(0x00AA);
LCD_WR_REG(0xF002);    LCD_WR_DATA(0x0052);
LCD_WR_REG(0xF003);    LCD_WR_DATA(0x0008);
LCD_WR_REG(0xF004);    LCD_WR_DATA(0x0001);

//Set AVDD 5.2V
LCD_WR_REG(0xB000);    LCD_WR_DATA(0x000D);
LCD_WR_REG(0xB001);    LCD_WR_DATA(0x000D);
LCD_WR_REG(0xB002);    LCD_WR_DATA(0x000D);

//Set AVEE 5.2V
LCD_WR_REG(0xB100);    LCD_WR_DATA(0x000D);
LCD_WR_REG(0xB101);    LCD_WR_DATA(0x000D);
LCD_WR_REG(0xB102);    LCD_WR_DATA(0x000D);

//Set VCL -2.5V
LCD_WR_REG(0xB200);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xB201);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xB202);    LCD_WR_DATA(0x0000);				

//Set AVDD Ratio
LCD_WR_REG(0xB600);    LCD_WR_DATA(0x0044);
LCD_WR_REG(0xB601);    LCD_WR_DATA(0x0044);
LCD_WR_REG(0xB602);    LCD_WR_DATA(0x0044);

//Set AVEE Ratio
LCD_WR_REG(0xB700);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xB701);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xB702);    LCD_WR_DATA(0x0034);

//Set VCL -2.5V
LCD_WR_REG(0xB800);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xB801);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xB802);    LCD_WR_DATA(0x0034);
			
//Control VGH booster voltage rang
LCD_WR_REG(0xBF00);    LCD_WR_DATA(0x0001); //VGH:7~18V	

//VGH=15V(1V/step)	Free pump
LCD_WR_REG(0xB300);    LCD_WR_DATA(0x000f);		//08
LCD_WR_REG(0xB301);    LCD_WR_DATA(0x000f);		//08
LCD_WR_REG(0xB302);    LCD_WR_DATA(0x000f);		//08

//VGH Ratio
LCD_WR_REG(0xB900);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xB901);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xB902);    LCD_WR_DATA(0x0034);

//VGL_REG=-10(1V/step)
LCD_WR_REG(0xB500);    LCD_WR_DATA(0x0008);
LCD_WR_REG(0xB501);    LCD_WR_DATA(0x0008);
LCD_WR_REG(0xB502);    LCD_WR_DATA(0x0008);

LCD_WR_REG(0xC200);    LCD_WR_DATA(0x0003);

//VGLX Ratio
LCD_WR_REG(0xBA00);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xBA01);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xBA02);    LCD_WR_DATA(0x0034);

	//VGMP/VGSP=4.5V/0V
LCD_WR_REG(0xBC00);    LCD_WR_DATA(0x0000);		//00
LCD_WR_REG(0xBC01);    LCD_WR_DATA(0x0078);		//C8 =5.5V/90=4.8V
LCD_WR_REG(0xBC02);    LCD_WR_DATA(0x0000);		//01

//VGMN/VGSN=-4.5V/0V
LCD_WR_REG(0xBD00);    LCD_WR_DATA(0x0000); //00
LCD_WR_REG(0xBD01);    LCD_WR_DATA(0x0078); //90
LCD_WR_REG(0xBD02);    LCD_WR_DATA(0x0000);

//Vcom=-1.4V(12.5mV/step)
LCD_WR_REG(0xBE00);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xBE01);    LCD_WR_DATA(0x0064); //HSD:64;Novatek:50=-1.0V, 80  5f

//Gamma (R+)
LCD_WR_REG(0xD100);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD101);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD102);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD103);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD104);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD105);    LCD_WR_DATA(0x003A);
LCD_WR_REG(0xD106);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD107);    LCD_WR_DATA(0x004A);
LCD_WR_REG(0xD108);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD109);    LCD_WR_DATA(0x005C);
LCD_WR_REG(0xD10A);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD10B);    LCD_WR_DATA(0x0081);
LCD_WR_REG(0xD10C);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD10D);    LCD_WR_DATA(0x00A6);
LCD_WR_REG(0xD10E);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD10F);    LCD_WR_DATA(0x00E5);
LCD_WR_REG(0xD110);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD111);    LCD_WR_DATA(0x0013);
LCD_WR_REG(0xD112);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD113);    LCD_WR_DATA(0x0054);
LCD_WR_REG(0xD114);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD115);    LCD_WR_DATA(0x0082);
LCD_WR_REG(0xD116);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD117);    LCD_WR_DATA(0x00CA);
LCD_WR_REG(0xD118);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD119);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD11A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD11B);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD11C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD11D);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD11E);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD11F);    LCD_WR_DATA(0x0067);
LCD_WR_REG(0xD120);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD121);    LCD_WR_DATA(0x0084);
LCD_WR_REG(0xD122);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD123);    LCD_WR_DATA(0x00A4);
LCD_WR_REG(0xD124);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD125);    LCD_WR_DATA(0x00B7);
LCD_WR_REG(0xD126);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD127);    LCD_WR_DATA(0x00CF);
LCD_WR_REG(0xD128);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD129);    LCD_WR_DATA(0x00DE);
LCD_WR_REG(0xD12A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD12B);    LCD_WR_DATA(0x00F2);
LCD_WR_REG(0xD12C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD12D);    LCD_WR_DATA(0x00FE);
LCD_WR_REG(0xD12E);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD12F);    LCD_WR_DATA(0x0010);
LCD_WR_REG(0xD130);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD131);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD132);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD133);    LCD_WR_DATA(0x006D);

//Gamma (G+)
LCD_WR_REG(0xD200);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD201);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD202);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD203);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD204);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD205);    LCD_WR_DATA(0x003A);
LCD_WR_REG(0xD206);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD207);    LCD_WR_DATA(0x004A);
LCD_WR_REG(0xD208);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD209);    LCD_WR_DATA(0x005C);
LCD_WR_REG(0xD20A);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD20B);    LCD_WR_DATA(0x0081);
LCD_WR_REG(0xD20C);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD20D);    LCD_WR_DATA(0x00A6);
LCD_WR_REG(0xD20E);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD20F);    LCD_WR_DATA(0x00E5);
LCD_WR_REG(0xD210);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD211);    LCD_WR_DATA(0x0013);
LCD_WR_REG(0xD212);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD213);    LCD_WR_DATA(0x0054);
LCD_WR_REG(0xD214);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD215);    LCD_WR_DATA(0x0082);
LCD_WR_REG(0xD216);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD217);    LCD_WR_DATA(0x00CA);
LCD_WR_REG(0xD218);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD219);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD21A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD21B);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD21C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD21D);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD21E);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD21F);    LCD_WR_DATA(0x0067);
LCD_WR_REG(0xD220);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD221);    LCD_WR_DATA(0x0084);
LCD_WR_REG(0xD222);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD223);    LCD_WR_DATA(0x00A4);
LCD_WR_REG(0xD224);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD225);    LCD_WR_DATA(0x00B7);
LCD_WR_REG(0xD226);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD227);    LCD_WR_DATA(0x00CF);
LCD_WR_REG(0xD228);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD229);    LCD_WR_DATA(0x00DE);
LCD_WR_REG(0xD22A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD22B);    LCD_WR_DATA(0x00F2);
LCD_WR_REG(0xD22C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD22D);    LCD_WR_DATA(0x00FE);
LCD_WR_REG(0xD22E);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD22F);    LCD_WR_DATA(0x0010);
LCD_WR_REG(0xD230);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD231);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD232);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD233);    LCD_WR_DATA(0x006D);

//Gamma (B+)
LCD_WR_REG(0xD300);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD301);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD302);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD303);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD304);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD305);    LCD_WR_DATA(0x003A);
LCD_WR_REG(0xD306);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD307);    LCD_WR_DATA(0x004A);
LCD_WR_REG(0xD308);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD309);    LCD_WR_DATA(0x005C);
LCD_WR_REG(0xD30A);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD30B);    LCD_WR_DATA(0x0081);
LCD_WR_REG(0xD30C);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD30D);    LCD_WR_DATA(0x00A6);
LCD_WR_REG(0xD30E);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD30F);    LCD_WR_DATA(0x00E5);
LCD_WR_REG(0xD310);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD311);    LCD_WR_DATA(0x0013);
LCD_WR_REG(0xD312);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD313);    LCD_WR_DATA(0x0054);
LCD_WR_REG(0xD314);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD315);    LCD_WR_DATA(0x0082);
LCD_WR_REG(0xD316);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD317);    LCD_WR_DATA(0x00CA);
LCD_WR_REG(0xD318);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD319);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD31A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD31B);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD31C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD31D);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD31E);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD31F);    LCD_WR_DATA(0x0067);
LCD_WR_REG(0xD320);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD321);    LCD_WR_DATA(0x0084);
LCD_WR_REG(0xD322);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD323);    LCD_WR_DATA(0x00A4);
LCD_WR_REG(0xD324);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD325);    LCD_WR_DATA(0x00B7);
LCD_WR_REG(0xD326);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD327);    LCD_WR_DATA(0x00CF);
LCD_WR_REG(0xD328);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD329);    LCD_WR_DATA(0x00DE);
LCD_WR_REG(0xD32A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD32B);    LCD_WR_DATA(0x00F2);
LCD_WR_REG(0xD32C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD32D);    LCD_WR_DATA(0x00FE);
LCD_WR_REG(0xD32E);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD32F);    LCD_WR_DATA(0x0010);
LCD_WR_REG(0xD330);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD331);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD332);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD333);    LCD_WR_DATA(0x006D);

//Gamma (R-)
LCD_WR_REG(0xD400);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD401);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD402);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD403);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD404);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD405);    LCD_WR_DATA(0x003A);
LCD_WR_REG(0xD406);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD407);    LCD_WR_DATA(0x004A);
LCD_WR_REG(0xD408);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD409);    LCD_WR_DATA(0x005C);
LCD_WR_REG(0xD40A);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD40B);    LCD_WR_DATA(0x0081);
LCD_WR_REG(0xD40C);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD40D);    LCD_WR_DATA(0x00A6);
LCD_WR_REG(0xD40E);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD40F);    LCD_WR_DATA(0x00E5);
LCD_WR_REG(0xD410);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD411);    LCD_WR_DATA(0x0013);
LCD_WR_REG(0xD412);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD413);    LCD_WR_DATA(0x0054);
LCD_WR_REG(0xD414);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD415);    LCD_WR_DATA(0x0082);
LCD_WR_REG(0xD416);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD417);    LCD_WR_DATA(0x00CA);
LCD_WR_REG(0xD418);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD419);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD41A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD41B);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD41C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD41D);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD41E);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD41F);    LCD_WR_DATA(0x0067);
LCD_WR_REG(0xD420);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD421);    LCD_WR_DATA(0x0084);
LCD_WR_REG(0xD422);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD423);    LCD_WR_DATA(0x00A4);
LCD_WR_REG(0xD424);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD425);    LCD_WR_DATA(0x00B7);
LCD_WR_REG(0xD426);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD427);    LCD_WR_DATA(0x00CF);
LCD_WR_REG(0xD428);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD429);    LCD_WR_DATA(0x00DE);
LCD_WR_REG(0xD42A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD42B);    LCD_WR_DATA(0x00F2);
LCD_WR_REG(0xD42C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD42D);    LCD_WR_DATA(0x00FE);
LCD_WR_REG(0xD42E);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD42F);    LCD_WR_DATA(0x0010);
LCD_WR_REG(0xD430);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD431);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD432);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD433);    LCD_WR_DATA(0x006D);

//Gamma (G-)
LCD_WR_REG(0xD500);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD501);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD502);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD503);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD504);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD505);    LCD_WR_DATA(0x003A);
LCD_WR_REG(0xD506);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD507);    LCD_WR_DATA(0x004A);
LCD_WR_REG(0xD508);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD509);    LCD_WR_DATA(0x005C);
LCD_WR_REG(0xD50A);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD50B);    LCD_WR_DATA(0x0081);
LCD_WR_REG(0xD50C);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD50D);    LCD_WR_DATA(0x00A6);
LCD_WR_REG(0xD50E);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD50F);    LCD_WR_DATA(0x00E5);
LCD_WR_REG(0xD510);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD511);    LCD_WR_DATA(0x0013);
LCD_WR_REG(0xD512);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD513);    LCD_WR_DATA(0x0054);
LCD_WR_REG(0xD514);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD515);    LCD_WR_DATA(0x0082);
LCD_WR_REG(0xD516);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD517);    LCD_WR_DATA(0x00CA);
LCD_WR_REG(0xD518);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD519);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD51A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD51B);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD51C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD51D);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD51E);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD51F);    LCD_WR_DATA(0x0067);
LCD_WR_REG(0xD520);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD521);    LCD_WR_DATA(0x0084);
LCD_WR_REG(0xD522);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD523);    LCD_WR_DATA(0x00A4);
LCD_WR_REG(0xD524);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD525);    LCD_WR_DATA(0x00B7);
LCD_WR_REG(0xD526);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD527);    LCD_WR_DATA(0x00CF);
LCD_WR_REG(0xD528);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD529);    LCD_WR_DATA(0x00DE);
LCD_WR_REG(0xD52A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD52B);    LCD_WR_DATA(0x00F2);
LCD_WR_REG(0xD52C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD52D);    LCD_WR_DATA(0x00FE);
LCD_WR_REG(0xD52E);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD52F);    LCD_WR_DATA(0x0010);
LCD_WR_REG(0xD530);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD531);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD532);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD533);    LCD_WR_DATA(0x006D);

//Gamma (B-)
LCD_WR_REG(0xD600);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD601);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD602);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD603);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD604);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD605);    LCD_WR_DATA(0x003A);
LCD_WR_REG(0xD606);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD607);    LCD_WR_DATA(0x004A);
LCD_WR_REG(0xD608);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD609);    LCD_WR_DATA(0x005C);
LCD_WR_REG(0xD60A);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD60B);    LCD_WR_DATA(0x0081);
LCD_WR_REG(0xD60C);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD60D);    LCD_WR_DATA(0x00A6);
LCD_WR_REG(0xD60E);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD60F);    LCD_WR_DATA(0x00E5);
LCD_WR_REG(0xD610);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD611);    LCD_WR_DATA(0x0013);
LCD_WR_REG(0xD612);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD613);    LCD_WR_DATA(0x0054);
LCD_WR_REG(0xD614);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD615);    LCD_WR_DATA(0x0082);
LCD_WR_REG(0xD616);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD617);    LCD_WR_DATA(0x00CA);
LCD_WR_REG(0xD618);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD619);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0xD61A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD61B);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xD61C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD61D);    LCD_WR_DATA(0x0034);
LCD_WR_REG(0xD61E);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD61F);    LCD_WR_DATA(0x0067);
LCD_WR_REG(0xD620);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD621);    LCD_WR_DATA(0x0084);
LCD_WR_REG(0xD622);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD623);    LCD_WR_DATA(0x00A4);
LCD_WR_REG(0xD624);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD625);    LCD_WR_DATA(0x00B7);
LCD_WR_REG(0xD626);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD627);    LCD_WR_DATA(0x00CF);
LCD_WR_REG(0xD628);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD629);    LCD_WR_DATA(0x00DE);
LCD_WR_REG(0xD62A);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD62B);    LCD_WR_DATA(0x00F2);
LCD_WR_REG(0xD62C);    LCD_WR_DATA(0x0002);
LCD_WR_REG(0xD62D);    LCD_WR_DATA(0x00FE);
LCD_WR_REG(0xD62E);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD62F);    LCD_WR_DATA(0x0010);
LCD_WR_REG(0xD630);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD631);    LCD_WR_DATA(0x0033);
LCD_WR_REG(0xD632);    LCD_WR_DATA(0x0003);
LCD_WR_REG(0xD633);    LCD_WR_DATA(0x006D);

//PAGE0
LCD_WR_REG(0xF000);    LCD_WR_DATA(0x0055);
LCD_WR_REG(0xF001);    LCD_WR_DATA(0x00AA);
LCD_WR_REG(0xF002);    LCD_WR_DATA(0x0052);
LCD_WR_REG(0xF003);    LCD_WR_DATA(0x0008);	
LCD_WR_REG(0xF004);    LCD_WR_DATA(0x0000); 

//480x800
LCD_WR_REG(0xB500);    LCD_WR_DATA(0x0050);

//LCD_WR_REG(0x2C00);    LCD_WR_DATA(0x0006); //8BIT 6-6-6?

//Dispay control
LCD_WR_REG(0xB100);    LCD_WR_DATA(0x00CC);	
LCD_WR_REG(0xB101);    LCD_WR_DATA(0x0000); // S1->S1440:00;S1440->S1:02

//Source hold time (Nova non-used)
LCD_WR_REG(0xB600);    LCD_WR_DATA(0x0005);

//Gate EQ control	 (Nova non-used)
LCD_WR_REG(0xB700);    LCD_WR_DATA(0x0077);  //HSD:70;Nova:77	 
LCD_WR_REG(0xB701);    LCD_WR_DATA(0x0077);	//HSD:70;Nova:77

//Source EQ control (Nova non-used)
LCD_WR_REG(0xB800);    LCD_WR_DATA(0x0001);  
LCD_WR_REG(0xB801);    LCD_WR_DATA(0x0003);	//HSD:05;Nova:07
LCD_WR_REG(0xB802);    LCD_WR_DATA(0x0003);	//HSD:05;Nova:07
LCD_WR_REG(0xB803);    LCD_WR_DATA(0x0003);	//HSD:05;Nova:07

//Inversion mode: column
LCD_WR_REG(0xBC00);    LCD_WR_DATA(0x0002);	//00: column
LCD_WR_REG(0xBC01);    LCD_WR_DATA(0x0000);	//01:1dot
LCD_WR_REG(0xBC02);    LCD_WR_DATA(0x0000); 

//Frame rate	(Nova non-used)
LCD_WR_REG(0xBD00);    LCD_WR_DATA(0x0001);
LCD_WR_REG(0xBD01);    LCD_WR_DATA(0x0084);
LCD_WR_REG(0xBD02);    LCD_WR_DATA(0x001c); //HSD:06;Nova:1C
LCD_WR_REG(0xBD03);    LCD_WR_DATA(0x001c); //HSD:04;Nova:1C
LCD_WR_REG(0xBD04);    LCD_WR_DATA(0x0000);

//LGD timing control(4H/4-delay_ms)
LCD_WR_REG(0xC900);    LCD_WR_DATA(0x00D0);	//3H:0x50;4H:0xD0	 //D
LCD_WR_REG(0xC901);    LCD_WR_DATA(0x0002);  //HSD:05;Nova:02
LCD_WR_REG(0xC902);    LCD_WR_DATA(0x0050);	//HSD:05;Nova:50
LCD_WR_REG(0xC903);    LCD_WR_DATA(0x0050);	//HSD:05;Nova:50	;STV delay_ms time
LCD_WR_REG(0xC904);    LCD_WR_DATA(0x0050);	//HSD:05;Nova:50	;CLK delay_ms time

LCD_WR_REG(0x3600);    LCD_WR_DATA(0x0000);
LCD_WR_REG(0x3500);    LCD_WR_DATA(0x0000);

LCD_WR_REG(0xFF00);    LCD_WR_DATA(0x00AA);
LCD_WR_REG(0xFF01);    LCD_WR_DATA(0x0055);
LCD_WR_REG(0xFF02);    LCD_WR_DATA(0x0025);
LCD_WR_REG(0xFF03);    LCD_WR_DATA(0x0001);

LCD_WR_REG(0xFC00);    LCD_WR_DATA(0x0016);
LCD_WR_REG(0xFC01);    LCD_WR_DATA(0x00A2);
LCD_WR_REG(0xFC02);    LCD_WR_DATA(0x0026);
LCD_WR_REG(0x3A00);    LCD_WR_DATA(0x0006);

LCD_WR_REG(0x3A00);    LCD_WR_DATA(0x0055);
//Sleep out
LCD_WR_REG(0x1100);	   //?
delay_ms(160);

//Display on
LCD_WR_REG(0x2900);    	

	
}



///===========END INITIAL=====================//
/**********************************************
��������LCD_Set
���ܣ�Lcd������ؼĴ����������� ѡ������������һ�־Ϳ���
����ֵ����
***********************************************/
void LCD_Set(void)
{

lcddev.width=480;    //LCD ����
lcddev.height=800;   //LCD �߶�
	//��������
//lcddev.width=480;    //LCD ����
//lcddev.height=320;   //LCD �߶�	
lcddev.setxcmd=0X2A00;  //����x����ָ��2A
lcddev.setycmd=0X2B00;  //����y����ָ��2B
lcddev.wramcmd=0X2C00;  //��ʼдgramָ��
	
}

///////////////���ֵ���////////////////	

/*******************************************************************************
* Function Name  : LCD_WriteRAM_Prepare  ��ʼдGRAM
* Description    : ��ʼдIC-GRAM�Ĵ�������
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TFT_WriteRAM(void)
{
LCD_WR_REG(lcddev.wramcmd);
//	LCD_WR_8REG(lcddev.wramcmd);	
}

//LCD������ʾ
void LCD_DisplayOn(void)
{					   
//	LCD_WR_REG(0X29);	//������ʾ
LCD_WR_8REG(0X29);
}	 

//LCD�ر���ʾ
void LCD_DisplayOff(void)
{	   
//	LCD_WR_REG(0X28);	//�ر���ʾ
LCD_WR_8REG(0X28);
}

/**********************************************
��������Lcd��ѡ����
���ܣ�ѡ��Lcd��ָ���ľ�������    ѡ������������һ�־Ϳ���
ע�⣺xStart��yStart��Xend��Yend������Ļ����ת���ı䣬λ���Ǿ��ο���ĸ���
��ڲ�����xStart x�������ʼ��
	  ySrart y�������ʼ��
	  Xend   y�������ֹ��
	  Yend   y�������ֹ��
����ֵ����
***********************************************/
void BlockWrite(unsigned int Xstart,unsigned int Xend,unsigned int Ystart,unsigned int Yend) 
{
	
//OTM8009,NT35510  OK20190601
	LCD_WR_REG(0x2a00);   
	LCD_WR_DATA(Xstart>>8);
	LCD_WR_REG(0x2a01); 
	LCD_WR_DATA(Xstart&0xff);
	LCD_WR_REG(0x2a02); 
	LCD_WR_DATA(Xend>>8);
	LCD_WR_REG(0x2a03); 
	LCD_WR_DATA(Xend&0xff);

	LCD_WR_REG(0x2b00);   
	LCD_WR_DATA(Ystart>>8);
	LCD_WR_REG(0x2b01); 
	LCD_WR_DATA(Ystart&0xff);
	LCD_WR_REG(0x2b02); 
	LCD_WR_DATA(Yend>>8);
	LCD_WR_REG(0x2b03); 
	LCD_WR_DATA(Yend&0xff);

	LCD_WR_REG(0x2c00);	

}

/*******************************************************************************/
///////////////���֣ɣô���//////////////

/*******************************************************************************
//��FSMC_8080.C�Ʒ�����TFTLCD_Init.c    20171120
//���ù��λ��    ѡ�����ö�����һ�־Ϳ���
//Xpos:������
//Ypos:������
*******************************************************************************/
void LCD_SetCursor(u16 Xpos, u16 Ypos)
{	 

//	LCDHVG35SetCursor(Xpos,Ypos);  //ILI9488 ,HX8357C,D,TEST 20171101_OKҪ�Ӻ����013F,01DF  OK
	

//OTM8009,NT35510  OK20190601
LCD_WR_REG(0x2a00);   
LCD_WR_DATA(Xpos>>8);
LCD_WR_REG(0x2a01);
LCD_WR_DATA(Xpos&0xff);
LCD_WR_REG(0x2a02);
LCD_WR_DATA(0x01);
LCD_WR_REG(0x2a03);
LCD_WR_DATA(0xE0);

LCD_WR_REG(0x2b00);   
LCD_WR_DATA(Ypos>>8);
LCD_WR_REG(0x2b01);
LCD_WR_DATA(Ypos&0xff);
LCD_WR_REG(0x2b02);
LCD_WR_DATA(0X03);
LCD_WR_REG(0x2b03);
LCD_WR_DATA(0x56);

LCD_WR_REG(0x2C00);		
	
	
}

/*******************************************************************************/
///////////////���////////////////

void LCDHVG35SetCursor(u16 Xpos, u16 Ypos)  //ILI9488 ,HX8357C,TEST 20171101_OKҪ�Ӻ����013F,01DF
{
	
 //ILI9488 ,HX8357C,TEST 20171101_OK

//LCD_WR_8REG(0x36);
//LCD_WR_8DATA(0x08); ///08(������),C8����װ�ã���A8(����FPC@IC����)��68(����FPC@IC����)
	
//LCD_WR_8REG(lcddev.setxcmd);  //20180430
LCD_WR_8REG(0X2A);	
LCD_WR_8DATA(Xpos>>8);
LCD_WR_8DATA(Xpos&0xff);
LCD_WR_8DATA(0x01);
LCD_WR_8DATA(0x3F);

//LCD_WR_8REG(lcddev.setycmd);  //20180430
LCD_WR_8REG(0X2B);	
LCD_WR_8DATA(Ypos>>8);
LCD_WR_8DATA(Ypos&0xff);
LCD_WR_8DATA(0x01);
LCD_WR_8DATA(0xDF);
	
LCD_WR_8REG(0x2C);


}


/*******************************************************************************/
/**********************************************
��������LCD_ReadID
���ܣ�LCD��ȡIC-ID  ѡ�����ö�����һ�־Ϳ���
����ֵ����
***********************************************/
//
void LCD_ReadID(void)
{

//	u8 lcd_id[12];	//���LCD ID�ַ���
/***********************************************/	
LCD_RESET();//��ȡǰ����и�λ����׼ȷ����
/***********************************************/

//	LcdILI9488ReadID();  //OK

//nt35510  NG
LCD_WR_REG(0X0400);
lcddev.id=LCD_RD_DATA();	
LCD_WR_REG(0X0401);
lcddev.id=LCD_RD_DATA();	//����
LCD_WR_REG(0X0402);
lcddev.id=LCD_RD_DATA();	//����	
lcddev.id<<=8;	
lcddev.id|=LCD_RD_DATA();  //����	
		
}

///////////////LCD-ID////////////////

void LcdILI9488ReadID(void)
{
unsigned char i;
/***********************************************/
//����9486,9488 ID�Ĳ��ڶ�ȡ	 OK20171127
LCD_WR_REG(0XD3);				   
lcddev.id=LCD_RD_DATA();	//dummy read 	
lcddev.id=LCD_RD_DATA();	//����0X00
lcddev.id=LCD_RD_DATA();   	//��ȡ94	
lcddev.id<<=8;
lcddev.id|=LCD_RD_DATA();  	//��ȡ86,88

sprintf((char*)lcd_id,"LCD ID:%04X",lcddev.id);//��LCD ID��ӡ��lcd_id����	

}

/*******************************************************************************/
//����LCDɨ�跽��
//��˳ʱ��ת����0:0�ȣ�1��90�ȣ�2��180�ȣ�3��270��
//9163,9331,9340,9341,7735,7789,8357D,9327,9488.HX8357C :  36h
// MY Row Address Order
// MX Column Address Order
// MV Row / Column Exchange
// ML Vertical Refresh Order
// (0=RGB color filter panel, 1=BGR color filter panel)
// MH Horizontal Refresh ORDER
// Horizontal Flip x
// Vertical Flip  y
/*******************************************************************************/
void TFT_Scan_Dir(u8 dir)	 
{
					
}

///===========END ==============//









